#!/usr/bin/python

# Made by Luke Dinkler and Peter Toth

from src.gui.gui import InitGUI #Imports GUI module

def start(): #Defines Start function
	gui = InitGUI() #Initializes GUI

if __name__ == '__main__':
	start() #Starts the Software

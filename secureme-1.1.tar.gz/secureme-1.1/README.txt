* * * * * * * * * * * * * * * * * * * * *
*                                       *
*           SecureMe Version 1          *
*                                       *
*  Made by Peter Toth and Luke Dinkler  *
*                                       *
*             25 JUNE 2015              *
*                                       *
* * * * * * * * * * * * * * * * * * * * *


---INSTALLATION INSTRUCTIONS0----------------------------------------------------------

1. Navigate to this folder in the terminal
2. Enter the following command:
	$ bash installer install
3. That's it! You have successfully installed SecureMe!

---USAGE-------------------------------------------------------------------------------

This program was intended to be used for positive motives; not for spying, hacking,
piracy, etc.

To run this program from the command prompt, enter the following command:
$ secureme

To run this program silently, enter this command:
$ secureme silent

To remove this program, enter this command:
$ secureme remove

---CHANGELOG---------------------------------------------------------------------------

SECUREME VERSION 1.1
! Fixed many bugs in installer

!!! SECUREME VERSION 1.0 !!! ( Out of Betas )
+ Created installer
! Project Clean up
+ Downloadable
- Removed Unused code

SECUREME BETA VERSION 1.5
+ Added background colors
! Changed toolbar colors

SECUREME BETA VERSION 1.4
! Changed Fonts
+ Fixed Firewall Bug
+ Fixed Root login Bug

SECUREME BETA VERSION 1.3
+ Added Margins for nicer look

SECUREME BETA VERSION 1.2
+ Added keyboard shortcut CTRL-R for Refresh function
+ Added Status bar
+ Fixed bug with toolbar

SECUREME BETA VERSION 1.1
+ Added auto-refresh
+ Added tool bar...
	+ Refresh button
	+ Exit button
+ Added menubar with same functions as tool bar

SECUREME BETA VERSION 1.0
+ First Release
+ Primary Settings Tab...
	+ System Actions...
		+ Button added to open terminal
		+ Button added to open control panel
		+ Button added to power off the system
		+ Button added to reboot the system
	+ System Updates...
		+ Button added for system update
		+ Button added for system upgrade
		+ Button added for package update
+ User Tab...
	+ Possible add/remove user/group ( IN PROGRESS )
	+ Shows Users
	+ Shows Groups
+ Firewall Tab...
	+ Enable Button to enable firewall
	+ Disable button to disable firewall
	+ Shows firewall status
+ Services Tab...
	+ Shows Services
+ Processes Tab...
	+ Shows Processes

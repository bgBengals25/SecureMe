#!/bin/bash

echo "SecureMe Installer Version 1.1"

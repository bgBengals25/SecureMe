#!/bin/bash

echo "The following options are valid arguments:"
echo "$ bash installer install"
echo "$ bash installer version"
echo "$ bash installer help"

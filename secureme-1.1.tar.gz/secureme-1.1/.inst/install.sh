#!/bin/bash

$p = $(pwd)

echo "Installing SecureMe..."

echo "Creating Directories..."
sudo mkdir /usr/share/secureme

echo "Copying Files..."
sudo cp -r .inst/content/* /usr/share/secureme
sudo cp -r README.txt /usr/share/secureme
sudo cp -r .inst/secureme /usr/bin
sudo cp -r .inst/secureme.desktop /usr/share/applications

echo "Checking Dependencies..."
sudo apt-get install python python-tk
